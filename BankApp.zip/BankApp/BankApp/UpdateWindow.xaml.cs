﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BankApp.Models;

namespace BankApp
{
    /// <summary>
    /// Interaction logic for UpdateWindow.xaml
    /// </summary>
    public partial class UpdateWindow : Window
    {
        private BankAppViewModel repo = new BankAppViewModel();
        public bool updated = false;
        public User user = new User();

        public UpdateWindow(User user)
        {

            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            this.user = user;
            user.Name = txtNewName.Text;
            user.Password = txtPass.Text;
            
        }

        public UpdateWindow()
        {
          
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

            if (!string.IsNullOrWhiteSpace(txtNewName.Text) && !string.IsNullOrWhiteSpace(txtPass.Text))
            {
                //User user = repo.GetUser(int.Parse(txtId.Text));
                user.Name = txtNewName.Text;
                user.Password = txtPass.Text;                
                repo.UpdateUser(user);
               
                this.Close();                

            }
            else
            {
                MessageBox.Show("Name and password fields cannot be empty.");
            }


        }
    }
}

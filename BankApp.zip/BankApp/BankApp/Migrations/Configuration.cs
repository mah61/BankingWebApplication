﻿namespace BankApp.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using System.Collections.Generic;
    using BankApp.Models;


    internal sealed class Configuration : DbMigrationsConfiguration<BankApp.Models.BankDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(BankApp.Models.BankDbContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.

            context.Users.RemoveRange(context.Users);
            context.Accounts.RemoveRange(context.Accounts);

            List<User> users = new List<User>();

            users.Add(new User()
            {
                Name = "admin",
                Password = "123",
                UserAccount = new Account()
                {
                    Balance = 0.00
                }

            });

            users.Add(new User()
            {
                Name = "Maria Smith",
                Password = "222",
                UserAccount = new Account()
                {
                    Balance = 1000.00
                }

            });

            users.Add(new User()
            {
                Name = "John Alfredo",
                Password = "712",
                UserAccount = new Account()
                {
                    Balance = 700.00
                }

            });

            context.Users.AddRange(users);
            base.Seed(context);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BankApp.Models;

namespace BankApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        private BankAppViewModel repo = new BankAppViewModel();
        private bool logedIn = false;
        private User current = new User();

        public MainWindow()
        {          
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }


        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (this.logedIn)

                this.Logout();

            else

                UserLogin();               

        }

        private void UserLogin()
        {
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.ShowDialog();
             if (loginWindow.login == false)
               return;
             txtId.Text = loginWindow.txtID.Text;
             User current = repo.GetUser(int.Parse(txtId.Text));
             txtName.Text = current.Name;
             txtBalance.Text = current.UserAccount.Balance.ToString("C");
             txtAmount.Text = 0.ToString();
             btnDeposit.IsEnabled = true;
             btnWithdraw.IsEnabled = true;
             btnLogin.Content = (object)"Log Out";
             txtAmount.IsEnabled = true;
             txtAmount.Focus();
             this.logedIn = true;                                                               
        }


        private void Logout()
        {

            txtId.Text = string.Empty;
            txtName.Text = string.Empty;
            txtBalance.Text = string.Empty;
            txtAmount.Text = string.Empty;
            txtBalance.IsEnabled = false;
            txtAmount.IsEnabled = false;
            btnDeposit.IsEnabled = false;
            btnWithdraw.IsEnabled = false;
            btnLogin.Content = (object)"Login";
            this.logedIn = false;

        }

        private void BtnDeposit_Click(object sender, RoutedEventArgs e)
        {
            if (checkInput())
            {
                User current = repo.GetUser(int.Parse(txtId.Text));
              
                double balance = current.UserAccount.Balance;                

                double newBalance = (double.Parse(txtAmount.Text) + balance);

                txtBalance.Text = newBalance.ToString("C");

                int AccuntNumber = current.UserAccount.AccountNumber;

                CreateTransactionFile(AccuntNumber, "D", balance, newBalance);

                try
                {
                   repo.UpdateBalance(int.Parse(this.txtId.Text), newBalance);

                    MessageBox.Show("Successful Transaction");
                    MessageBox.Show("The report is printed on transaction.txt");


                }
                catch (Exception ex)
                {

                    MessageBox.Show("Error" + ex.Message);
                }

            }

        }

        private void BtnWithdraw_Click(object sender, RoutedEventArgs e)
        {
            if (checkInput())
            {
                User current = repo.GetUser(int.Parse(txtId.Text));

                int AccuntNumber = current.UserAccount.AccountNumber;

                double balance = current.UserAccount.Balance;

                if (double.Parse(txtAmount.Text) > balance)
                {


                    MessageBox.Show("The amount is more than balance.");

                }
                else
                {

                    double newBalance = (balance - double.Parse(txtAmount.Text));

                    txtBalance.Text = newBalance.ToString("C");

                    CreateTransactionFile(AccuntNumber, "W", balance, newBalance);


                    try
                    {
                        repo.UpdateBalance(int.Parse(this.txtId.Text), newBalance);

                        MessageBox.Show("Successful Transaction");
                        MessageBox.Show("The report is printed on transaction.txt");

                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Error" + ex.Message);
                    }
                }
            }
        }

        private bool checkInput()
        {
            double input;
            if (double.TryParse(txtAmount.Text, out input))
             return true;
            MessageBox.Show("Amount can only be a number");
            return false;
        }

       


        private void CreateTransactionFile(int AccountNum, string action, double oldBalace, double newBalance)
        {
            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.Append(string.Format("[" + $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}" +"]" + "#" + AccountNum +
                " | " + action + " | " + oldBalace.ToString("c") + " | " + newBalance.ToString("c") + "\n"));

            //return stringBuilder.ToString();

            string path = "../../transaction.txt";

                if(File.Exists(path))
            {
                try
                {
                    StreamWriter streamWriter = new StreamWriter(path, true);
                    streamWriter.WriteLine(stringBuilder);
                    streamWriter.Close();                    
                }

                catch (Exception ex)
                {

                    MessageBox.Show("Error" + ex.Message);
                }

            }

        }
    }
}

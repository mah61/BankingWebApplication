﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp.Models
{

     class BankAppViewModel
    {
        BankDbContext context = new BankDbContext();

               
        public List<User> GetAllUserData()
          {
            return context.Users.Include("UserAccount").ToList();
          }

        public User VerifyUser(int ID, string Pass)
        {
            User current = (from u in context.Users.Include("UserAccount")
            where u.ID == ID && u.Password.Equals(Pass)
            select u).SingleOrDefault();

            return current;       
        }

        public User GetUser(int ID)
        {
            User current = (from u in context.Users.Include("UserAccount")
                            where u.ID == ID
                            select u).SingleOrDefault();

            return current;

        }

        public void AddNewUser(User newUser)
        {
            context.Users.Add(newUser);
            context.SaveChanges();
                        
        }

        public Account GetAccount(int ID)
        {
            return (from u in context.Users
                    where u.ID == ID
                    select u.UserAccount).SingleOrDefault();

        }

        public void DeleteUserAccount(int ID)
        {
            User toBeDeleted = (from u in context.Users
                                where u.ID == ID
                                select u).SingleOrDefault();

            Account AccountToBeDelete = GetAccount(ID);

            context.Accounts.Remove(AccountToBeDelete);
            context.Users.Remove(toBeDeleted);
            context.SaveChanges();

        }

        public void UpdateUser(User updated)
        {
            User current = (from u in context.Users
                            where u.ID == updated.ID
                            select u).SingleOrDefault();

            current.Name = updated.Name;
            current.Password = updated.Password;

            context.SaveChanges();

        }

        public void UpdateBalance(int ID, double balance)
        {
            User current = (from u in context.Users
                            where u.ID == ID
                            select u).SingleOrDefault();

            current.UserAccount.Balance = balance;

            context.SaveChanges();

        }

    }
 
}
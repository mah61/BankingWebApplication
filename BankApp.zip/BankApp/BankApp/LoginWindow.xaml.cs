﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BankApp.Models;

namespace BankApp
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
      
        private BankAppViewModel repo = new BankAppViewModel();
        public bool login = false;     

        
        public LoginWindow()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;


        }

        private void BtnLogIn_Click(object sender, RoutedEventArgs e)
        {
            string id = this.txtID.Text;
            string password = this.txtPassword.ToString();

            if (!string.IsNullOrWhiteSpace(id) && !string.IsNullOrWhiteSpace(password))
            {
                if (CheckID())
                {
                    User current = repo.VerifyUser(int.Parse(txtID.Text), txtPassword.Password);
                    if (current != null)
                    {

                        if (int.Parse(txtID.Text) == 4 && int.Parse(txtPassword.Password) == 123)
                        {
                            CallAdmin();
                            this.login = false;
                            return;
                        }
                        else
                        this.login = true;
                        MessageBox.Show($"Welcome {current.Name}!");
                        this.Close();
                        return;
                    }
                    else
                    this.login = false;
                    MessageBox.Show("Invalid ID/Password.");
                    
                }
                else
                    this.login = false;
            }
            else
            {
                MessageBox.Show("ID and password fields cannot be empty.");
            }
        }                                               

        
         private bool CheckID()
        {
            int value;
            if (int.TryParse(this.txtID.Text, out value))
                return true;
            MessageBox.Show("ID can only be a number.");
            return false;
        }


        private void CallAdmin()
        {
            MessageBox.Show("Welcome Admin!");
            this.Close();
            AdminWindow admin = new AdminWindow();
            admin.ShowDialog();

        }
}
    }


 

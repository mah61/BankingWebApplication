﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BankApp.Models;

namespace BankApp
{
    /// <summary>
    /// Interaction logic for AdminWindow.xaml
    /// </summary>
    public partial class AdminWindow : Window, IComponentConnector
    {
        private BankAppViewModel repo = new BankAppViewModel();
        
        public AdminWindow()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            dgUsers.ItemsSource = repo.GetAllUserData();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddWindow addWindow = new AddWindow();
            addWindow.ShowDialog();

            dgUsers.ItemsSource = repo.GetAllUserData();

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
           
            if (dgUsers.SelectedItem == null)
            {
                MessageBox.Show("Please selected a user first");

            }
            else
            {
                User user = dgUsers.SelectedItem as User;
                UpdateWindow updateWindow = new UpdateWindow(user);

                updateWindow.txtId.Text = user.ID.ToString();
                updateWindow.txtAccNum.Text = user.UserAccount.AccountNumber.ToString();
                
                updateWindow.ShowDialog();
                                 
                dgUsers.ItemsSource = repo.GetAllUserData();

            }

            
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgUsers.SelectedItem != null && MessageBox.Show("Are you sure you want to delete?\n"
                + "This will delete the Account records as well", "Confirm Delete", MessageBoxButton.YesNo
                , MessageBoxImage.Stop)== MessageBoxResult.Yes)
            {
                try
                {
                    repo.DeleteUserAccount((dgUsers.SelectedItem as User).ID);
                    dgUsers.ItemsSource = repo.GetAllUserData();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BankApp.Models;

namespace BankApp
{
    /// <summary>
    /// Interaction logic for AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window, IComponentConnector
    {
        private BankAppViewModel repo = new BankAppViewModel();
       // public User newUser = new User();

        public AddWindow()
        {
            InitializeComponent();
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        private void BtnAddUser_Click(object sender, RoutedEventArgs e)
        {
            repo.AddNewUser(GenerateNewUser());
            this.Close();

        }

        private User GenerateNewUser()
        {
              User newUser = new User();

            if (txtName.Text == string.Empty && txtPassword.Text == string.Empty)
            {
                MessageBox.Show("Name and password should not be null");
            }
            else
            {
                
                Account newAccount = new Account();
                newUser.Name = txtName.Text;
                newUser.Password = txtPassword.Text;
                newUser.UserAccount = newAccount;

            }

            return newUser;
        }
    }
}
